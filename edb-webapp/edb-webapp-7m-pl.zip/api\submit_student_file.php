<?php
// submit_student_file.php
require 'config.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['student_name']) || !isset($data['url']) || !isset($data['school_type'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Wszystkie pola są wymagane']);
    exit();
}

// Validate school type
$allowed_schools = ['prezentki', 'nazaret'];
if (!in_array($data['school_type'], $allowed_schools)) {
    http_response_code(400);
    echo json_encode(['error' => 'Nieprawidłowy wybór szkoły']);
    exit();
}

try {
    $stmt = $pdo->prepare("INSERT INTO student_submissions (student_name, url, school_type) VALUES (?, ?, ?)");
    $stmt->execute([$data['student_name'], $data['url'], $data['school_type']]);

    echo json_encode(['success' => true]);
}
catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Błąd serwera podczas zapisywania']);
}
?>
